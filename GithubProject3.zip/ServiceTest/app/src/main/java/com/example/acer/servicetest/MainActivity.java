package com.example.acer.servicetest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void startservice(View view) {
        Intent i=new Intent(this,MyMusicService.class);
        startService(i);
    }

    public void stopservice(View view) {
        Intent i1=new Intent(this,MyMusicService.class);
        stopService(i1);
    }
}
